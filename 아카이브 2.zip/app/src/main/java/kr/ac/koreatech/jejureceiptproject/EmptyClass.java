package kr.ac.koreatech.jejureceiptproject;

public class EmptyClass {
}
