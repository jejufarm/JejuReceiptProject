package kr.ac.koreatech.jejureceiptproject.viewmodel;

import android.view.View;
import android.widget.FrameLayout;

import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableField;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import kr.ac.koreatech.jejureceiptproject.R;
import kr.ac.koreatech.jejureceiptproject.view.activity.MainActivity;
import kr.ac.koreatech.jejureceiptproject.view.fragment.EditFragment;
import kr.ac.koreatech.jejureceiptproject.view.fragment.MainFragment;
import kr.ac.koreatech.jejureceiptproject.view.fragment.MoreFragment;

public class MainActivityViewModel {
    private static MainActivity mainActivity;

    // MainActivity의 현재 프래그먼트
    private ObservableField<Fragment> currFragment = new ObservableField<>();
    // 활성화 여부
    private ObservableField<Boolean> isMainActive = new ObservableField<>();
    private ObservableField<Boolean> isEditActive = new ObservableField<>();
    private ObservableField<Boolean> isMoreActive = new ObservableField<>();

    public MainActivityViewModel() {

    }

    public MainActivityViewModel(MainActivity mainActivity) {
        MainActivityViewModel.mainActivity = mainActivity;
        isMainActive.set(true);
    }

    //region getter setter
    public ObservableField<Boolean> isMainActive() {
        return isMainActive;
    }

    public void setMainActive(boolean mainActive) {
        isMainActive.set(mainActive);
    }

    public ObservableField<Boolean> isEditActive() {
        return isEditActive;
    }

    public void setEditActive(boolean editActive) {
        isEditActive.set(editActive);
    }

    public ObservableField<Boolean> isMoreActive() {
        return isMoreActive;
    }

    public void setMoreActive(boolean moreActive) {
        isMoreActive.set(moreActive);
    }

    public void setCurrFragment(Fragment fragment) {
        currFragment.set(fragment);
    }

    public ObservableField<Fragment> getCurrFragment() {
        return currFragment;
    }
    //endregion

    //region event
    public void navigation_onClick(View v) {
        switch (v.getId()) {
            case R.id.main_imageView_main: {
                currFragment.set(new MainFragment());
                setMainActive(true);
                setEditActive(false);
                setMoreActive(false);
                break;
            }
            case R.id.main_imageView_edit: {
                currFragment.set(new EditFragment());
                setMainActive(false);
                setEditActive(true);
                setMoreActive(false);
                break;
            }

            case R.id.main_imageView_more: {
                currFragment.set(new MoreFragment());
                setMainActive(false);
                setEditActive(false);
                setMoreActive(true);
                break;
            }
        }
    }
    //endregion

    //region BindingAdapter
    @BindingAdapter({"fragmentUrl"})
    public static void changeFragment(FrameLayout frameLayout, Fragment fragment) {
        if (fragment == null)
            fragment = new MainFragment();
        FragmentManager fm = mainActivity.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.fragment1, fragment);
        fragmentTransaction.commit();
    }
    //endregion
}
