package kr.ac.koreatech.jejureceiptproject.viewmodel;

import android.view.View;
import android.widget.AdapterView;

import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableField;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Objects;

import kr.ac.koreatech.jejureceiptproject.adapter.CactusListViewAdapter;
import kr.ac.koreatech.jejureceiptproject.adapter.CountListViewAdapter;


public class MainFragmentViewModel {
    private CactusListViewAdapter cactusListViewAdapter;
    private CountListViewAdapter countListViewAdapter;
    private ObservableField<String> selectCactus = new ObservableField<>();
    private ObservableField<String> selectCount = new ObservableField<>();


    public CactusListViewAdapter getCactusListViewAdapter() {
        return cactusListViewAdapter;
    }

    public void setCactusListViewAdapter(CactusListViewAdapter cactusListViewAdapter) {
        this.cactusListViewAdapter = cactusListViewAdapter;
    }

    public CountListViewAdapter getCountListViewAdapter() {
        return countListViewAdapter;
    }

    public void setCountListViewAdapter(CountListViewAdapter countListViewAdapter) {
        this.countListViewAdapter = countListViewAdapter;
    }

    public ObservableField<String> getSelectCactus() {
        return selectCactus;
    }

    public void setSelectCactus(String selectCactus) {
        this.selectCactus.set(selectCactus);
    }

    public ObservableField<String> getSelectCount() {
        return selectCount;
    }

    public void setSelectCount(String selectCount) {
        if (getSelectCount().get() != null && getSelectCount().get().length() < 3) {
            if (getSelectCount().get().length() == 0 && selectCount.equals("0"))
                return; // 맨 처음은 0이 올 수 없음.
            this.selectCount.set(getSelectCount().get() + selectCount);
        } else {
            if (!selectCount.equals("0"))
                this.selectCount.set(selectCount);

        }
    }
}