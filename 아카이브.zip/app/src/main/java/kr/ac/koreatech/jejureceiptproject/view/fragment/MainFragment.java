package kr.ac.koreatech.jejureceiptproject.view.fragment;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import kr.ac.koreatech.jejureceiptproject.R;
import kr.ac.koreatech.jejureceiptproject.adapter.CactusListViewAdapter;
import kr.ac.koreatech.jejureceiptproject.adapter.CountListViewAdapter;
import kr.ac.koreatech.jejureceiptproject.databinding.FragmentMainBinding;
import kr.ac.koreatech.jejureceiptproject.domain.CactusDTO;
import kr.ac.koreatech.jejureceiptproject.viewmodel.MainFragmentViewModel;


public class MainFragment extends Fragment {
    private MainFragmentViewModel mainFragmentViewModel;

    private FragmentMainBinding binding;

    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainFragmentViewModel = new MainFragmentViewModel();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false);
        binding.setViewModel(mainFragmentViewModel);
        getCactusList();
        initCountList();
        return binding.getRoot();
    }

    private void initCountList() {
        List<Integer> temp = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            temp.add(i);
        }
        mainFragmentViewModel.setCountListViewAdapter(new CountListViewAdapter(temp, getLayoutInflater()));

        binding.countListView.setOnItemClickListener((adapterView, view, i, l) -> {
            final Integer selectedItem = (Integer) mainFragmentViewModel.getCountListViewAdapter().getItem(i);
            mainFragmentViewModel.setSelectCount(
                    String.format("%s", selectedItem)
            );
        });
    }

    private void getCactusList() {
        List<CactusDTO> temp = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            temp.add(new CactusDTO((long) i, "테스트" + i, i * 10000 + 10000));
        }
        mainFragmentViewModel.setCactusListViewAdapter(new CactusListViewAdapter(temp, getLayoutInflater()));
        binding.cactusListView.setOnItemClickListener((adapterView, view, i, l) -> {
            final CactusDTO selectedItem = (CactusDTO) mainFragmentViewModel.getCactusListViewAdapter().getItem(i);
            mainFragmentViewModel.setSelectCactus(
                    String.format("%s %10s %-1s",
                            selectedItem.getName(),
                            "",
                            new DecimalFormat("###,###").format(selectedItem.getPrice())
                    )
            );
        });
    }
}